$(function() {

    getBillsInfo();
    
    });


const addEmployee = (e) => {

    e.preventDefault();

    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Save it!'
    }).then((result) => {
        if (result.isConfirmed) {
            const emp_name = $("#emp_name").val();
            const emp_add = $("#emp_add").val();
            const emp_nic = $("#emp_nic").val();
            const emp_date = $("#emp_date").val();
            const employee = $("#employee").val();



            //add bill api

            $.ajax({
                type: "POST",
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                data: `empName=+${encodeURIComponent(emp_name)}`+`&empAddress=+${encodeURIComponent(emp_add)}`+`&empNIC=+${encodeURIComponent(emp_nic)}`+`&empDOB=+${encodeURIComponent(emp_date)}`+`&empContact=+${encodeURIComponent(employee)}`,
                url: "http://localhost:8090/API/webapi/API/addEmployeeInfo",
                success: function (data) {
                    console.log(data);
                    if (data) {
                        Swal.fire(
                            'Successful!',
                            'Employee Details Saved!',
                            'success'
                        );
                        clearForm();
                    } else {
                        Swal.fire(
                            'Error!',
                            'Unable to save!',
                            'error'
                        );
                    }


                }
            });
        }
    })
}

const updateEmployee = (e) => {

    e.preventDefault();

    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Save it!'
    }).then((result) => {
        if (result.isConfirmed) {
            const emp_name = $("#emp_name").val();
            const emp_add = $("#emp_add").val();
            const emp_nic = $("#emp_nic").val();
            const emp_date = $("#emp_date").val();
            const employee = $("#employee").val();


            //add bill api

            $.ajax({
                type: "POST",
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                data: $.param({empID: emp_num,empName: emp_name, empAddress : emp_add, empNIC : emp_nic,empDOB: emp_date,empContact:employee}),
                url: "http://localhost:8090/API/webapi/API/updateEmployeeInfo",
                success: function (data) {
                    console.log(data);
                    if (data) {
                        Swal.fire(
                            'Successful!',
                            'Employee Details Saved!',
                            'success'
                        );
                        clearForm();
                        $("#addBtn").show();
                        $("updateBtn").hide();
                    } else {
                        Swal.fire(
                            'Error!',
                            'Unable to save!',
                            'error'
                        );
                    }


                }
            });
        }
    })
}

const getBillsInfo = () => {
    $.ajax({
		type: "GET",
		url: "http://localhost:8090/API/webapi/API/getAllEmployeeInfo",
		headers: {'Content-Type': 'application/x-www-form-urlencoded'},
		//data: $.param({username: $scope.userName, password: $scope.password}),
		success: function (data) {
            alert(JSON.stringify(data));
			 
			$('#tblViewempmanage > tbody').html('');
            $.each(data.data, function (i, bill) {
				appenEmployeeTable(bill);
			});
			
		}
	});
}

const appenEmployeeTable = (item) => {
	
	let textToInsert = '';
	textToInsert += addRow(item);
	$('#tblViewempmanage > tbody').append(textToInsert);
};

const addRow = (item) => {
	
	const delete_btn = '<button type="button" class="btn btn-danger btn-xs" id="' + item.empID + 'delete" onclick="removeemployee(\'' + item.empID + '\')"><span class="fas fa-trash-alt"></span>&nbsp;Delete Employee</button>';
	
    //pay_num,acc_num,cous_id,pay_date,payment
    const update_btn = '<button type="button" class="btn btn-waring btn-xs" id="' + item.empID + 'delete" onclick="setUpdateData(\'' + item.empID+'\',\''+item.empName+ '\',\''+item.empAddress+ '\',\''+item.empNIC+'\',\''+item.empDOB+'\',\''+item.empContact+'\')"><span class="fas fa-edit"></span>&nbsp;Edit Employee</button>';
	
//idpay_bill, cus_id, bill_no, month, tot_amount, status
	let row = '<tr id="' + item.empID + '">'
        + '<td>#</td>'
        + '<td>' + item.empID + '</td>'
		+ '<td>' + item.empName + '</td>'
		+ '<td>' + item.empAddress + '</td>'
		+ '<td>' + item.empNIC + '</td>'
		+ '<td>' + item.empDOB + '</td>'
        + '<td>' + item.empContact + '</td>'
		+ '<td>'
			+ update_btn
		+ '</td>'
		+ '<td>'
			+ delete_btn
		+ '</td>'
		+ '</tr>';
	return row;
};


const setUpdateDate=(emp_num,emp_name,emp_add,emp_nic,emp_date,employee)=>{

    $("#emp_id").val(emp_num);
    $("#emp_name").val(emp_name);
    $("#emp_add").val(emp_add);
    $("#emp_nic").val(emp_nic);
    $("#emp_date").val(emp_date);
    $("#employee").val(employee);

    $("#addBtn").hide();
    $("updateBtn").show();
}

const removeemployee = (ids) => {

    // e.preventDefault();

    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Save it!'
    }).then((result) => {
        if (result.isConfirmed) {
            const emp_num = ids;

            //add bill api

            $.ajax({
                type: "POST",
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                data: `paymentData=+${encodeURIComponent(emp_num)}`,
                url: "http://localhost:8090/API/webapi/API/removeEmployeeInfo",
                success: function (data) {
                    console.log(data);
                    if (data) {
                        Swal.fire(
                            'Successful!',
                            'Employee Details Removed!',
                            'success'
                        );
                        clearForm();
                        getBillsInfo();
                    } else {
                        Swal.fire(
                            'Error!',
                            'Unable to remove!',
                            'error'
                        );
                    }


                }
            });
        }
    })
}

